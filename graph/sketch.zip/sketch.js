function preload() {
  //my table is comma separated value "csv"
  //and has a header specifying the columns labels
  table = loadTable("data/HDI3.csv", "csv", "header");
  console.log(table);
}

function setup() {
//THIS IS JUST GENERAL EXAMPLES ABOUT LOOPING THROUGH ROWS AND COLUMNS
  //count the columns
   console.log(table.getRowCount() + " total rows in table");
   console.log(table.getColumnCount() + " total columns in table");

  // console.log(table.getColumn("name"));

  //cycle through the table
//   for (var r = 0; r < table.getRowCount(); r++)
//     for (var c = 0; c < table.getColumnCount(); c++) {
//       // console.log(table.getString(r, c));
//     }
    
    createCanvas(windowWidth, windowHeight);
    background(255)
    text("Human Development Index",20,20)
   
//the drawing of axes is now in a separate functions. You don't need to touch that. 
 makeAxis();
 
//Here is an array for countries (by rownumber)
var rowArray = [11,22,33,44,55]

//HERE IS THE CODE FOR DRAWING THE COUNTRIES
//IT STARTS BY GOING LOOPS THROUGH ROWS
     for (var i = 0; i < rowArray.length; i++) {
     	//IT GETS THINGS READY TO DRAW
       var countryName = table.getString(rowArray[i], 1);
        textAlign(RIGHT,CENTER);
        var startYpoint = 0;
        stroke(40*i)
        fill(40*i)
        noFill();
         beginShape();
         //THEN IT LOOPS THROUGH COLUMNS TO GET THE POINTS FOR THAT COUNTRY
        for (var c = 2; c < table.getColumnCount(); c++) {
          var theYear = Number(table.getString(0, c))
          var Yvalue = Number(table.getString(rowArray[i], c))
          if(!isNaN(Yvalue) && Yvalue > 0) {
            var Xpoint = map(theYear,1980,2015,150,width-50);
            var Ypoint = map(Yvalue,0,1,height-50,50);
            ellipse(Xpoint,Ypoint,8,8);
            if(startYpoint === 0) {
              startYpoint = Yvalue;
              text(countryName,Xpoint-10,Ypoint)
              curveVertex(Xpoint,Ypoint);
              curveVertex(Xpoint,Ypoint);
            } else if (c == table.getColumnCount() - 1) {
              curveVertex(Xpoint,Ypoint);
              curveVertex(Xpoint,Ypoint);
              } else {
              curveVertex(Xpoint,Ypoint);
              
            }
          }
          
        }
        endShape();
        
     }

}



// function draw() {
// don't need draw to run  
// }

function makeAxis() {

    //draw xaxis
    line(150,height-50,width-50,height-50);
    //draw yaxis
    line(150,50,150,height-50);
    //xaxis vaules
    for(var i = 0; i < 1.1; i = i + 0.2) {
      //rounding is here because of floating point issue
      var rounded = Math.round( i * 10 ) / 10;
      yvalue = map(i,0,1,height-50,50);
      textAlign(RIGHT,CENTER)
      text(rounded,140,yvalue);
      line(145,yvalue,155,yvalue);
    }
    //yaxis values
     for (var c = 2; c < table.getColumnCount(); c++) {
       //number() is here, though might not need
       var myYear = Number(table.getString(0, c))
   //    console.log(myYear);
       var xvalue = map(myYear,1980,2015,150,width-50)
      // console.log(table.columns[c]);
       textAlign(CENTER,BOTTOM);
       text(myYear,xvalue,height-30);
       line(xvalue,height-55,xvalue,height-45);
       
     }
}